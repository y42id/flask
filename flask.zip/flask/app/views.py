# -*- coding:utf-8 -*-

"""
    POUR VOUS CONNECTER ET POUVOIR UTILISER TOUTES LES FONCTIONNALITES DU SITE ALLEZ DANS LA NAVBAR PUIS CONNEXION:
    USERNAME = admin PASSWORD = admin"""

from flask import render_template, flash, redirect, url_for,request, session, g
from functools import wraps
from app import app
import sqlite3
from app import model



app.secret_key="paris_saint_germain"
app.database = "exemple.db"

def connect_db():
    return sqlite3.connect(app.database)


#demande de log pour acces aux pages spécifiques
def demande_log(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('Vous devez vous authentifier')
            return redirect(url_for('login'))
    return wrap





#TEST de demande de log pour acces aux posts
@app.route('/')
@app.route('/index/')
@demande_log
def index():
    g.db = connect_db()
    cur = g.db.execute('select * from post')
    post = [dict(titre = row[1], description = row [2],utilisateur_id = row[3]) for row in cur.fetchall()]
    g.db.close()
    return render_template('index.html', post = post)

#TEST d'une page html
@app.route('/a_propos/')
def apropos():
    return "Site réalisé dans le cadre de mes etudes de L2 informatique"

#TEST DE REDIRECTION HTML Acceuil et redirection vers les post les plus recent
@app.route('/accueil/')
def accueil():
    return render_template('accueil.html')


#TEST TEMPLATE JINJA ET INSERCTION DANS LA BDD
@app.route('/inscription/', methods=['GET', 'POST'])
def inscription():
    if request.method == 'POST':
        model.Interaction.formulaire()
        return redirect(url_for('entry_page'))
    else:
        return render_template('inscription.html')

#TEST INSERTION ET SELECTION DANS LA BDD
@app.route('/post/', methods=['GET', 'POST'])
@demande_log
def entry_page():
    if request.method == 'POST':
        model.Interaction.publication()
        return redirect(url_for('index'))
    else:
        return render_template('post.html')


#TEST DE VERIFICATION ENTRE LA BDD ET LES SAISIE DE L'UTILISATEUR
@app.route('/login/', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        model.Interaction.authentification()
        return redirect(url_for('entry_page'))
    return render_template('login.html')


#DECONNEXION
@app.route('/logout/')
def logout():
    session.pop('logged_in', None)
    flash('Vous vous etes deconnecté')
    return redirect(url_for('accueil'))
