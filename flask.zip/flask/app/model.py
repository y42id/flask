# coding=utf-8
from __future__ import absolute_import
from flask import render_template, flash, redirect, url_for,request, session
import sqlite3
from flask import g


def connect_db():
    return sqlite3.connect('exemple.db')


def get_db():
    if not hasattr(g, 'sqlite_db'):
        g.sqlite_db = connect_db()
    return g.sqlite_db

class Interaction(object):

    @classmethod
    def formulaire(cls):
        pseudo = request.form['pseudo']
        mail = request.form['mail']
        mdp = request.form['mot_de_passe']
        c = connect_db()
        c.execute('insert into utilisateur(pseudo,mot_de_passe, mail) values(?, ?, ?)', (pseudo,mdp,mail))
        c.commit()
        c.close()

    @classmethod
    def publication(cls):
        utilisateur = connect_db()
        #valeur=utilisateur.execute("""SELECT pseudo FROM utilisateur ORDER BY id DESC LIMIT 1""")
        utilisateur.commit()
        valeur = utilisateur.execute("""select p.titre, p.description, u.pseudo from post p inner join utilisateur u on u.id = p.utilisateur_id""")
        cur = valeur.fetchone()
        utilisateur.close()
        title = request.form['titre']
        post = request.form['description']
        c = connect_db()
        post_entry = c.execute('insert into post(titre, description,utilisateur_id)values(?, ? ,?)',(str(title),str(post),cur[0],))
        c.commit()
        c.close()

    @classmethod
    def authentification(cls):
        g.db = connect_db()
        user=request.form['username']
        passw=request.form['password']
        c = g.db.execute("SELECT pseudo from utilisateur where pseudo = (?)", [user])
        userexists = c.fetchone()
        if userexists:
            c = g.db.execute("SELECT mot_de_passe from utilisateur where mot_de_passe = (?)", [passw])
            passwcorrect = c.fetchone()
            if passwcorrect:
                session['logged_in']=True
                flash("Vous etes connecté")
                return redirect(url_for('index'))
            else:
                return flash("mot de passe invalide")
        return flash("inscription requise utilisateur introuvable")








