PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS utilisateur;
CREATE TABLE IF NOT EXISTS utilisateur(
  id INTEGER PRIMARY KEY ASC,
  pseudo VARCHAR(200) UNIQUE NOT NULL,
  mot_de_passe VARCHAR(30)  NOT NULL,
  mail VARCHAR(300) UNIQUE NOT NULL 
);

DROP TABLE IF EXISTS post;
CREATE TABLE IF NOT EXISTS post(
  id INTEGER PRIMARY KEY ASC,
  titre VARCHAR(300),
  description TEXT,
  utilisateur_id INTEGER NOT NULL,
  FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id)
);