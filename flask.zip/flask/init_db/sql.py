import sqlite3

#creation de la conexion
with sqlite3.connect("exemple.db") as connection:
	c = connection.cursor()
	#creation de la table
	c.execute("""DROP TABLE IF EXISTS post""")
	c.execute("""DROP TABLE IF EXISTS utilisateur""")
	c.execute("""CREATE TABLE utilisateur(id INTEGER PRIMARY KEY ASC,pseudo TEXT NOT NULL,mot_de_passe TEXT NOT NULL, mail TEXT NOT  NULL UNIQUE)""")
	c.execute("""CREATE TABLE post(id INTEGER PRIMARY KEY ASC, titre TEXT, description TEXT,utilisateur_id INTEGER NOT NULL, FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id))""")

	
	#insertion de donnees
	c.execute('INSERT INTO utilisateur VALUES ("1","pegasus","pegasusfrolife","pegasus@hotmail.fr")')
	c.execute('INSERT INTO post VALUES ("1","Deschamps vs Cantonna","Cantonna à accusé deschamps de racisme!","1")')
	c.execute('INSERT INTO post VALUES ("2","Varane","Varane est blessé il ne participera pas à l\'euro","1")')